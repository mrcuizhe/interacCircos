Document is available at 

- [rNGCircos-jupyter notebook](https://mrcuizhe.github.io/rNGCircos_document/index.html)

Or 

- [rNGCircos-pdf](https://github.com/mrcuizhe/rNGCircos/blob/master/doc/rNGCircos_1.0.0.pdf)